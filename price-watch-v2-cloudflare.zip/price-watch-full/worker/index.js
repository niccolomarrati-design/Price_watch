/**
 * Price Watch — Cloudflare Worker
 *
 * Routes:
 *   POST   /api/auth/register        crea account (email + password hash)
 *   POST   /api/auth/login           restituisce un token JWT-like (firmato con HMAC)
 *   GET    /api/products             lista prodotti dell'utente
 *   POST   /api/products             aggiunge un prodotto (URL → worker estrae prezzo)
 *   DELETE /api/products/:id         rimuove un prodotto
 *   PATCH  /api/products/:id         aggiorna target_price / titolo
 *   GET    /api/products/:id/history storico prezzi paginato
 *   POST   /api/check                forza controllo immediato (tutti i prodotti utente)
 *   GET    /api/me                   info account + piano attivo
 *   POST   /api/admin/override-plan  [chiave gestore] sovrascrive piano
 *   GET    /api/admin/log            [chiave gestore] log di esecuzione
 *   DELETE /api/admin/log            [chiave gestore] svuota log
 *   GET    /api/admin/stats          [chiave gestore] statistiche globali
 *
 * Cron:
 *   ogni ora → controlla tutti i prodotti attivi di tutti gli utenti
 *
 * Env vars (impostare in wrangler.toml / dashboard Cloudflare):
 *   DB              → binding D1
 *   TOKEN_SECRET    → stringa segreta per firmare i token (min 32 char)
 *   ADMIN_KEY       → chiave gestore (es. "Niccolò_Quantistica")
 *   ALLORIGINS_BASE → (opzionale) proxy CORS alternativo; default allorigins.win
 */

// ── CORS ──────────────────────────────────────────────────────────────────────
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function cors(body, status = 200, extra = {}) {
  return new Response(body, { status, headers: { ...CORS, "Content-Type": "application/json", ...extra } });
}
function ok(data)        { return cors(JSON.stringify(data)); }
function err(msg, s=400) { return cors(JSON.stringify({ error: msg }), s); }

// ── TOKEN (HMAC-SHA256 base64url, no librerie esterne) ────────────────────────
async function signToken(payload, secret) {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const data = btoa(JSON.stringify(payload));
  const sig  = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)));
  return `${data}.${sigB64}`;
}

async function verifyToken(token, secret) {
  try {
    const [data, sigB64] = token.split(".");
    const key = await crypto.subtle.importKey(
      "raw", new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" }, false, ["verify"]
    );
    const sig = Uint8Array.from(atob(sigB64), c => c.charCodeAt(0));
    const ok2  = await crypto.subtle.verify("HMAC", key, sig, new TextEncoder().encode(data));
    if (!ok2) return null;
    const payload = JSON.parse(atob(data));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}

// ── PASSWORD HASH (PBKDF2) ────────────────────────────────────────────────────
async function hashPassword(password, saltHex) {
  const salt = saltHex
    ? Uint8Array.from(saltHex.match(/.{2}/g), h => parseInt(h, 16))
    : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations: 100_000 }, key, 256
  );
  const hash    = [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, "0")).join("");
  const saltOut = [...salt].map(b => b.toString(16).padStart(2, "0")).join("");
  return { hash, salt: saltOut };
}

// ── AUTH MIDDLEWARE ───────────────────────────────────────────────────────────
async function requireAuth(req, env) {
  const auth = req.headers.get("Authorization") || "";
  const token = auth.replace("Bearer ", "").trim();
  if (!token) return null;
  return verifyToken(token, env.TOKEN_SECRET);
}

// ── PIANI ─────────────────────────────────────────────────────────────────────
const PLANS = {
  free: { maxProducts: 30,       historyDays: 7    },
  pro:  { maxProducts: 70,       historyDays: 90   },
  max:  { maxProducts: Infinity, historyDays: 1095 },
  god:  { maxProducts: Infinity, historyDays: 9999 },
};

// ── ESTRAZIONE PREZZO DA HTML ─────────────────────────────────────────────────
function extractPriceFromHTML(html, url) {
  // Amazon buybox
  if (url && /amazon\./i.test(url)) {
    const block = html.match(/id="corePriceDisplay_desktop_feature_div"[\s\S]{0,3000}?<\/div>/);
    const area  = block ? block[0] : html;
    const m     = area.match(/class="a-offscreen">\s*([\d.,]+)\s*€/);
    if (m) {
      const v = parseFloat(m[1].replace(/\./g, "").replace(",", "."));
      if (!isNaN(v)) return v;
    }
  }

  // Meta tag Open Graph / itemprop
  function readMeta(attr, val) {
    const re = new RegExp(`<meta[^>]+${attr}=["']${val}["'][^>]*>`, "i");
    const tm = html.match(re);
    if (!tm) return null;
    const cm = tm[0].match(/content=["']([\d.,]+)["']/i);
    return cm ? cm[1] : null;
  }
  for (const raw of [
    readMeta("property", "product:price:amount"),
    readMeta("property", "og:price:amount"),
    readMeta("itemprop", "price"),
  ]) {
    if (raw) { const v = parseFloat(raw.replace(",", ".")); if (!isNaN(v)) return v; }
  }

  // JSON-LD schema.org
  for (const m of html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const data  = JSON.parse(m[1]);
      const items = Array.isArray(data) ? data : [data];
      for (const item of items) {
        const offers = item.offers || (item["@graph"]?.find(g => g.offers)?.offers);
        if (offers) {
          const price = offers.price || (Array.isArray(offers) && offers[0]?.price);
          const v = parseFloat(String(price).replace(",", "."));
          if (!isNaN(v)) return v;
        }
      }
    } catch {}
  }

  // Fallback: regex su importi in formato "123,45 €"
  const counts = new Map();
  for (const m of html.matchAll(/(\d{1,3}(?:\.\d{3})*,\d{2})\s?€|€\s?(\d{1,3}(?:\.\d{3})*,\d{2})/g)) {
    const raw = m[1] || m[2];
    const v   = parseFloat(raw.replace(/\./g, "").replace(",", "."));
    if (!isNaN(v)) counts.set(v, (counts.get(v) || 0) + 1);
  }
  if (counts.size > 0) {
    let best = null;
    for (const [price, count] of counts) {
      if (!best || count > best.count) best = { price, count };
    }
    return best.price;
  }

  return null;
}

// Sanity check: se il prezzo letto è 50× più alto del precedente ed è intero
// → probabilmente è in centesimi → dividi per 100.
function sanityCheck(newPrice, oldPrice) {
  if (oldPrice && newPrice > oldPrice * 50 && Number.isInteger(newPrice)) {
    const c = newPrice / 100;
    if (Math.abs(c - oldPrice) / oldPrice < 0.5) return c;
  }
  return newPrice;
}

// ── FETCH PREZZO (con retry su allorigins) ────────────────────────────────────
async function fetchPrice(url, previousPrice = null) {
  const proxy = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
  const res   = await fetch(proxy, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; PriceWatchBot/1.0)" },
    signal:  AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const html  = await res.text();
  const title = html.match(/<title[^>]*>([^<]{1,150})<\/title>/i)?.[1]?.trim() ?? null;
  let price   = extractPriceFromHTML(html, url);
  if (price !== null && previousPrice !== null) price = sanityCheck(price, previousPrice);
  return { price, title };
}

// ── LOG DI ESECUZIONE ─────────────────────────────────────────────────────────
async function appendLog(db, entry) {
  await db.prepare(
    `INSERT INTO execution_log (ts, user_id, product_id, product_title, result, message)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).bind(Date.now(), entry.userId ?? null, entry.productId ?? null,
         entry.title ?? null, entry.result, entry.message).run();
  // Mantiene solo le ultime 500 voci
  await db.prepare(
    `DELETE FROM execution_log WHERE id NOT IN
     (SELECT id FROM execution_log ORDER BY ts DESC LIMIT 500)`
  ).run();
}

// ── CONTROLLO PREZZI (usato sia dal cron che dall'endpoint /api/check) ─────────
async function checkProducts(db, userId = null) {
  // Se userId è null → controlla tutti gli utenti (cron)
  const rows = userId
    ? await db.prepare(`SELECT p.*, u.plan, u.notify_mode, u.notify_all_drops
                         FROM products p JOIN users u ON p.user_id = u.id
                         WHERE p.user_id = ? AND p.active = 1`).bind(userId).all()
    : await db.prepare(`SELECT p.*, u.plan, u.notify_mode, u.notify_all_drops
                         FROM products p JOIN users u ON p.user_id = u.id
                         WHERE p.active = 1`).all();

  const products = rows.results ?? [];
  let updated = 0;

  for (const product of products) {
    try {
      const { price: newPrice, title } = await fetchPrice(product.url, product.current_price);

      if (newPrice === null) {
        await db.prepare(`UPDATE products SET last_check_at = ?, last_check_error = ? WHERE id = ?`)
          .bind(Date.now(), "Prezzo non trovato nella pagina.", product.id).run();
        await appendLog(db, { userId: product.user_id, productId: product.id, title: product.title, result: "error", message: "Prezzo non trovato" });
        continue;
      }

      const dropped = newPrice < product.current_price;
      const changed = newPrice !== product.current_price;

      // Aggiorna titolo se era nullo
      const newTitle = product.title || title || product.url;

      await db.prepare(
        `UPDATE products SET current_price = ?, last_check_at = ?, last_check_error = NULL, title = ? WHERE id = ?`
      ).bind(newPrice, Date.now(), newTitle, product.id).run();

      // Inserisce sempre una rilevazione nello storico
      await db.prepare(
        `INSERT INTO price_history (product_id, price, recorded_at) VALUES (?, ?, ?)`
      ).bind(product.id, newPrice, Date.now()).run();

      // Pulizia storico in base al piano
      const planDays = PLANS[product.plan]?.historyDays ?? 7;
      if (planDays !== 9999) {
        const cutoff = Date.now() - planDays * 86_400_000;
        await db.prepare(
          `DELETE FROM price_history WHERE product_id = ? AND recorded_at < ?
           AND id NOT IN (SELECT id FROM price_history WHERE product_id = ? ORDER BY recorded_at DESC LIMIT 1)`
        ).bind(product.id, cutoff, product.id).run();
      }

      await appendLog(db, {
        userId: product.user_id, productId: product.id, title: newTitle,
        result: changed ? "changed" : "ok",
        message: changed
          ? `${(product.current_price).toFixed(2)}€ → ${newPrice.toFixed(2)}€`
          : `Invariato (${newPrice.toFixed(2)}€)`,
      });

      updated++;
    } catch (e) {
      await db.prepare(`UPDATE products SET last_check_at = ?, last_check_error = ? WHERE id = ?`)
        .bind(Date.now(), "Errore di rete: " + (e.message ?? String(e)), product.id).run();
      await appendLog(db, { userId: product.user_id, productId: product.id, title: product.title, result: "error", message: String(e.message ?? e) });
    }
  }

  return { checked: products.length, updated };
}

// ── ROUTER ────────────────────────────────────────────────────────────────────
export default {

  // ── CRON: ogni ora controlla tutti i prodotti ────────────────────────────
  async scheduled(event, env, ctx) {
    ctx.waitUntil(checkProducts(env.DB));
  },

  // ── HTTP REQUESTS ────────────────────────────────────────────────────────
  async fetch(req, env) {
    const url    = new URL(req.url);
    const path   = url.pathname;
    const method = req.method;

    // Preflight CORS
    if (method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

    // ── REGISTER ──────────────────────────────────────────────────────────
    if (path === "/api/auth/register" && method === "POST") {
      const { email, password } = await req.json().catch(() => ({}));
      if (!email || !password) return err("email e password obbligatorie");
      if (password.length < 8)  return err("password troppo corta (min 8 caratteri)");

      const exists = await env.DB.prepare(`SELECT id FROM users WHERE email = ?`).bind(email.toLowerCase()).first();
      if (exists) return err("email già registrata", 409);

      const { hash, salt } = await hashPassword(password);
      const id = crypto.randomUUID();
      await env.DB.prepare(
        `INSERT INTO users (id, email, password_hash, password_salt, plan, created_at) VALUES (?, ?, ?, ?, 'free', ?)`
      ).bind(id, email.toLowerCase(), hash, salt, Date.now()).run();

      const token = await signToken({ sub: id, exp: Date.now() + 30 * 86_400_000 }, env.TOKEN_SECRET);
      return ok({ token, userId: id, plan: "free" });
    }

    // ── LOGIN ─────────────────────────────────────────────────────────────
    if (path === "/api/auth/login" && method === "POST") {
      const { email, password } = await req.json().catch(() => ({}));
      if (!email || !password) return err("email e password obbligatorie");

      const user = await env.DB.prepare(`SELECT * FROM users WHERE email = ?`).bind(email.toLowerCase()).first();
      if (!user) return err("credenziali non valide", 401);

      const { hash } = await hashPassword(password, user.password_salt);
      if (hash !== user.password_hash) return err("credenziali non valide", 401);

      const token = await signToken({ sub: user.id, exp: Date.now() + 30 * 86_400_000 }, env.TOKEN_SECRET);
      return ok({ token, userId: user.id, plan: user.plan });
    }

    // ── DA QUI IN POI: richiede autenticazione ────────────────────────────
    const payload = await requireAuth(req, env);
    if (!payload && path.startsWith("/api/") && !path.startsWith("/api/auth/")) {
      return err("non autenticato", 401);
    }
    const userId = payload?.sub;

    // ── ME ────────────────────────────────────────────────────────────────
    if (path === "/api/me" && method === "GET") {
      const user = await env.DB.prepare(`SELECT id, email, plan, created_at FROM users WHERE id = ?`).bind(userId).first();
      if (!user) return err("utente non trovato", 404);
      const count = await env.DB.prepare(`SELECT COUNT(*) AS n FROM products WHERE user_id = ? AND active = 1`).bind(userId).first();
      return ok({ ...user, productCount: count.n });
    }

    // ── PRODUCTS LIST ─────────────────────────────────────────────────────
    if (path === "/api/products" && method === "GET") {
      const rows = await env.DB.prepare(
        `SELECT id, url, title, current_price, target_price, last_check_at, last_check_error, created_at
         FROM products WHERE user_id = ? AND active = 1 ORDER BY created_at DESC`
      ).bind(userId).all();
      return ok(rows.results ?? []);
    }

    // ── ADD PRODUCT ───────────────────────────────────────────────────────
    if (path === "/api/products" && method === "POST") {
      const { url: productUrl, targetPrice } = await req.json().catch(() => ({}));
      if (!productUrl || !productUrl.startsWith("http")) return err("URL non valido");

      const user = await env.DB.prepare(`SELECT plan FROM users WHERE id = ?`).bind(userId).first();
      const plan  = user?.plan ?? "free";
      const limit = PLANS[plan]?.maxProducts ?? 30;
      const count = await env.DB.prepare(`SELECT COUNT(*) AS n FROM products WHERE user_id = ? AND active = 1`).bind(userId).first();
      if (limit !== Infinity && count.n >= limit) return err(`Limite di ${limit} prodotti raggiunto. Aggiorna il piano.`, 403);

      // Fetch prezzo iniziale
      let price = null, title = null;
      try {
        const res = await fetchPrice(productUrl);
        price = res.price;
        title = res.title;
      } catch (e) {
        return err("Impossibile recuperare il prezzo da questo URL: " + (e.message ?? e));
      }
      if (price === null) return err("Prezzo non trovato nella pagina. Prova un altro URL.");

      const id = crypto.randomUUID();
      const now = Date.now();
      await env.DB.prepare(
        `INSERT INTO products (id, user_id, url, title, current_price, target_price, active, created_at, last_check_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`
      ).bind(id, userId, productUrl, title ?? productUrl, price, targetPrice ?? null, now, now).run();

      await env.DB.prepare(
        `INSERT INTO price_history (product_id, price, recorded_at) VALUES (?, ?, ?)`
      ).bind(id, price, now).run();

      return ok({ id, url: productUrl, title: title ?? productUrl, current_price: price, target_price: targetPrice ?? null, last_check_at: now });
    }

    // ── DELETE PRODUCT ────────────────────────────────────────────────────
    const deleteMatch = path.match(/^\/api\/products\/([^/]+)$/);
    if (deleteMatch && method === "DELETE") {
      const productId = deleteMatch[1];
      const row = await env.DB.prepare(`SELECT id FROM products WHERE id = ? AND user_id = ?`).bind(productId, userId).first();
      if (!row) return err("prodotto non trovato", 404);
      await env.DB.prepare(`UPDATE products SET active = 0 WHERE id = ?`).bind(productId).run();
      return ok({ deleted: true });
    }

    // ── PATCH PRODUCT (target_price / title) ──────────────────────────────
    const patchMatch = path.match(/^\/api\/products\/([^/]+)$/);
    if (patchMatch && method === "PATCH") {
      const productId = patchMatch[1];
      const body = await req.json().catch(() => ({}));
      const row  = await env.DB.prepare(`SELECT id FROM products WHERE id = ? AND user_id = ?`).bind(productId, userId).first();
      if (!row) return err("prodotto non trovato", 404);

      const fields = [], vals = [];
      if ("targetPrice" in body) { fields.push("target_price = ?"); vals.push(body.targetPrice); }
      if ("title"       in body) { fields.push("title = ?");        vals.push(body.title); }
      if (fields.length === 0)   return err("nessun campo da aggiornare");

      vals.push(productId);
      await env.DB.prepare(`UPDATE products SET ${fields.join(", ")} WHERE id = ?`).bind(...vals).run();
      return ok({ updated: true });
    }

    // ── HISTORY ───────────────────────────────────────────────────────────
    const histMatch = path.match(/^\/api\/products\/([^/]+)\/history$/);
    if (histMatch && method === "GET") {
      const productId = histMatch[1];
      const row = await env.DB.prepare(`SELECT id FROM products WHERE id = ? AND user_id = ?`).bind(productId, userId).first();
      if (!row) return err("prodotto non trovato", 404);
      const limit  = Math.min(parseInt(url.searchParams.get("limit") ?? "200"), 1000);
      const rows   = await env.DB.prepare(
        `SELECT price, recorded_at FROM price_history WHERE product_id = ? ORDER BY recorded_at DESC LIMIT ?`
      ).bind(productId, limit).all();
      return ok(rows.results ?? []);
    }

    // ── CHECK NOW ─────────────────────────────────────────────────────────
    if (path === "/api/check" && method === "POST") {
      const result = await checkProducts(env.DB, userId);
      return ok(result);
    }

    // ── ADMIN: richiede chiave gestore ────────────────────────────────────
    if (path.startsWith("/api/admin/")) {
      const adminKey = req.headers.get("X-Admin-Key") || "";
      if (adminKey !== env.ADMIN_KEY) return err("chiave gestore non valida", 403);

      // Override piano
      if (path === "/api/admin/override-plan" && method === "POST") {
        const { targetUserId, plan } = await req.json().catch(() => ({}));
        if (!PLANS[plan]) return err("piano non valido");
        const uid = targetUserId || userId;
        await env.DB.prepare(`UPDATE users SET plan = ? WHERE id = ?`).bind(plan, uid).run();
        return ok({ plan, userId: uid });
      }

      // Log
      if (path === "/api/admin/log" && method === "GET") {
        const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "200"), 500);
        const rows  = await env.DB.prepare(
          `SELECT * FROM execution_log ORDER BY ts DESC LIMIT ?`
        ).bind(limit).all();
        return ok(rows.results ?? []);
      }
      if (path === "/api/admin/log" && method === "DELETE") {
        await env.DB.prepare(`DELETE FROM execution_log`).run();
        return ok({ deleted: true });
      }

      // Statistiche globali
      if (path === "/api/admin/stats" && method === "GET") {
        const [users, products, history, errors] = await Promise.all([
          env.DB.prepare(`SELECT COUNT(*) AS n FROM users`).first(),
          env.DB.prepare(`SELECT COUNT(*) AS n FROM products WHERE active = 1`).first(),
          env.DB.prepare(`SELECT COUNT(*) AS n FROM price_history`).first(),
          env.DB.prepare(`SELECT COUNT(*) AS n FROM execution_log WHERE result = 'error'`).first(),
        ]);
        return ok({ users: users.n, activeProducts: products.n, historyRows: history.n, errors: errors.n });
      }
    }

    return new Response("Not found", { status: 404, headers: CORS });
  },
};
