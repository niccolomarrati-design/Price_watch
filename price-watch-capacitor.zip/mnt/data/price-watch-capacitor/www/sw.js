/* Price Watch - Web Push Service Worker */
self.addEventListener("push", (event) => {
  let payload = {};
  try {
    payload = event.data ? event.data.json() : {};
  } catch {
    payload = { body: event.data ? event.data.text() : "" };
  }

  const title = payload.title || "🔔 Price Watch";
  const options = {
    body: payload.body || "Il prezzo di un prodotto è cambiato.",
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    tag: payload.productId ? `price-watch-${payload.productId}` : "price-watch",
    renotify: true,
    data: {
      url: payload.url || "/",
      productId: payload.productId || null,
    },
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || "/";

  event.waitUntil((async () => {
    const absoluteUrl = new URL(targetUrl, self.location.origin).href;
    const clientsList = await clients.matchAll({ type: "window", includeUncontrolled: true });

    for (const client of clientsList) {
      if ("focus" in client) {
        if ("navigate" in client) await client.navigate(absoluteUrl);
        return client.focus();
      }
    }

    if (clients.openWindow) return clients.openWindow(absoluteUrl);
    return undefined;
  })());
});

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
