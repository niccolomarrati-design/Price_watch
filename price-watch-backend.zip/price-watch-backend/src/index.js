// src/index.js — Price Watch backend su Cloudflare Workers + D1
//
// Endpoint disponibili:
//   POST /auth/register   { email, password }        -> { token, plan }
//   POST /auth/login      { email, password }        -> { token, plan }
//   GET  /me                                          -> { email, plan }
//   GET  /products                                    -> [ { id, url, title, currentPrice, ... } ]
//   POST /products        { url, title, currentPrice, targetPrice? }
//   PATCH /products/:id   { targetPrice }
//   DELETE /products/:id
//   GET  /products/:id/history                        -> [ { price, date } ]
//   POST /check-now                                    -> ricontrolla subito i prodotti dell'utente
//
// Più uno scheduled handler (Cron Trigger, vedi wrangler.toml) che controlla
// i prodotti "scaduti" in base al piano del proprietario, e ripulisce lo
// storico più vecchio del limite del piano.

const PLAN_LIMITS = {
  free: { maxProducts: 30, historyDays: 7, checkIntervalMs: 24 * 60 * 60 * 1000 },
  pro: { maxProducts: 70, historyDays: 90, checkIntervalMs: 60 * 60 * 1000 },
  max: { maxProducts: Infinity, historyDays: 1095, checkIntervalMs: 20 * 60 * 1000 },
  god: { maxProducts: Infinity, historyDays: 999999, checkIntervalMs: 15 * 60 * 1000 },
};

// ---------- Utility: risposte JSON + CORS ----------
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*", // per iniziare; si può restringere in seguito
  "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS },
  });
}

// ---------- Utility: password hashing (PBKDF2, nessuna libreria esterna) ----------
function toHex(buffer) {
  return [...new Uint8Array(buffer)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function fromHex(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  return bytes;
}

async function hashPassword(password, saltHex = null) {
  const salt = saltHex ? fromHex(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    keyMaterial,
    256
  );
  return { hash: toHex(bits), salt: toHex(salt) };
}

async function verifyPassword(password, hashHex, saltHex) {
  const { hash } = await hashPassword(password, saltHex);
  return hash === hashHex;
}

// ---------- Utility: token firmato (HMAC-SHA256), niente librerie JWT esterne ----------
function base64url(bytes) {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function base64urlToBytes(str) {
  str = str.replace(/-/g, "+").replace(/_/g, "/");
  while (str.length % 4) str += "=";
  return Uint8Array.from(atob(str), c => c.charCodeAt(0));
}

async function signToken(payload, secret) {
  const data = new TextEncoder().encode(JSON.stringify(payload));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, data);
  return `${base64url(data)}.${base64url(new Uint8Array(sig))}`;
}

async function verifyToken(token, secret) {
  if (!token) return null;
  const [dataB64, sigB64] = token.split(".");
  if (!dataB64 || !sigB64) return null;
  const data = base64urlToBytes(dataB64);
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  const valid = await crypto.subtle.verify("HMAC", key, base64urlToBytes(sigB64), data);
  if (!valid) return null;
  try {
    const payload = JSON.parse(new TextDecoder().decode(data));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

async function requireAuth(request, env) {
  const authHeader = request.headers.get("Authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "");
  const payload = await verifyToken(token, env.JWT_SECRET);
  if (!payload) return null;
  const user = await env.DB.prepare("SELECT id, email, plan FROM users WHERE id = ?").bind(payload.sub).first();
  return user || null;
}

// ---------- Estrazione prezzo (stessa logica dell'estensione, adattata) ----------
function extractPriceFromHTML(html, url) {
  if (url && /amazon\./i.test(url)) {
    const coreBlockMatch = html.match(/id="corePriceDisplay_desktop_feature_div"[\s\S]{0,3000}?<\/div>/);
    const searchArea = coreBlockMatch ? coreBlockMatch[0] : html;
    const amazonMatch = searchArea.match(/class="a-offscreen">\s*([\d.,]+)\s*€/);
    if (amazonMatch) {
      const value = parseFloat(amazonMatch[1].replace(/\./g, "").replace(",", "."));
      if (!isNaN(value)) return value;
    }
  }

  function readMetaContent(attrName, attrValue) {
    const tagPattern = new RegExp(`<meta[^>]+${attrName}=["']${attrValue}["'][^>]*>`, "i");
    const tagMatch = html.match(tagPattern);
    if (!tagMatch) return null;
    const contentMatch = tagMatch[0].match(/content=["']([\d.,]+)["']/i);
    return contentMatch ? contentMatch[1] : null;
  }

  const metaCandidates = [
    readMetaContent("property", "product:price:amount"),
    readMetaContent("property", "og:price:amount"),
    readMetaContent("itemprop", "price"),
  ];
  for (const raw of metaCandidates) {
    if (raw) {
      const value = parseFloat(raw.replace(",", "."));
      if (!isNaN(value)) return value;
    }
  }

  const ldMatches = html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi);
  for (const m of ldMatches) {
    try {
      const data = JSON.parse(m[1]);
      const items = Array.isArray(data) ? data : [data];
      for (const item of items) {
        const offers = item.offers || (item["@graph"] && item["@graph"].find(g => g.offers)?.offers);
        if (offers) {
          const price = offers.price || (Array.isArray(offers) && offers[0]?.price);
          const value = parseFloat(String(price).replace(",", "."));
          if (!isNaN(value)) return value;
        }
      }
    } catch { /* JSON malformato, ignora */ }
  }

  const priceRegex = /(\d{1,3}(?:\.\d{3})*,\d{2})\s?€|€\s?(\d{1,3}(?:\.\d{3})*,\d{2})/g;
  const counts = new Map();
  for (const m of html.matchAll(priceRegex)) {
    const raw = m[1] || m[2];
    const value = parseFloat(raw.replace(/\./g, "").replace(",", "."));
    if (!isNaN(value)) counts.set(value, (counts.get(value) || 0) + 1);
  }
  if (counts.size > 0) {
    let best = null;
    for (const [price, count] of counts.entries()) {
      if (!best || count > best.count) best = { price, count };
    }
    return best.price;
  }
  return null;
}

function sanityCheckPrice(newPrice, previousPrice) {
  if (previousPrice && newPrice > previousPrice * 50 && Number.isInteger(newPrice)) {
    const corrected = newPrice / 100;
    if (Math.abs(corrected - previousPrice) / previousPrice < 0.5) return corrected;
  }
  return newPrice;
}

// ---------- Controllo di un singolo prodotto ----------
async function checkOneProduct(env, product) {
  const now = Date.now();
  try {
    const res = await fetch(product.url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; PriceWatchBot/1.0)" },
    });
    if (!res.ok) {
      await env.DB.prepare("UPDATE products SET last_checked_at=?, last_check_error=? WHERE id=?")
        .bind(now, `Errore HTTP ${res.status}`, product.id).run();
      return { ok: false, message: `Errore HTTP ${res.status}` };
    }
    const html = await res.text();
    let newPrice = extractPriceFromHTML(html, product.url);
    if (newPrice !== null) newPrice = sanityCheckPrice(newPrice, product.current_price);

    if (newPrice === null) {
      await env.DB.prepare("UPDATE products SET last_checked_at=?, last_check_error=? WHERE id=?")
        .bind(now, "Prezzo non trovato nella pagina", product.id).run();
      return { ok: false, message: "Prezzo non trovato" };
    }

    await env.DB.prepare("UPDATE products SET current_price=?, last_checked_at=?, last_check_error=NULL WHERE id=?")
      .bind(newPrice, now, product.id).run();
    await env.DB.prepare("INSERT INTO price_history (id, product_id, price, date) VALUES (?,?,?,?)")
      .bind(crypto.randomUUID(), product.id, newPrice, now).run();

    return { ok: true, price: newPrice };
  } catch (err) {
    await env.DB.prepare("UPDATE products SET last_checked_at=?, last_check_error=? WHERE id=?")
      .bind(now, String(err && err.message || err), product.id).run();
    return { ok: false, message: String(err && err.message || err) };
  }
}

// ---------- Scheduled: controlla i prodotti "scaduti" + pulizia storico ----------
async function checkDueProducts(env) {
  const now = Date.now();
  const rows = await env.DB.prepare(`
    SELECT p.*, u.plan as user_plan FROM products p
    JOIN users u ON u.id = p.user_id
    WHERE p.last_checked_at IS NULL OR (
      (u.plan = 'free' AND ? - p.last_checked_at >= ?) OR
      (u.plan = 'pro'  AND ? - p.last_checked_at >= ?) OR
      (u.plan = 'max'  AND ? - p.last_checked_at >= ?) OR
      (u.plan = 'god'  AND ? - p.last_checked_at >= ?)
    )
    LIMIT 200
  `).bind(
    now, PLAN_LIMITS.free.checkIntervalMs,
    now, PLAN_LIMITS.pro.checkIntervalMs,
    now, PLAN_LIMITS.max.checkIntervalMs,
    now, PLAN_LIMITS.god.checkIntervalMs
  ).all();

  for (const product of rows.results) {
    await checkOneProduct(env, product);
  }

  // Pulizia storico in base al piano (equivalente di pruneHistory nell'estensione)
  for (const [plan, limits] of Object.entries(PLAN_LIMITS)) {
    const cutoff = now - limits.historyDays * 24 * 60 * 60 * 1000;
    await env.DB.prepare(`
      DELETE FROM price_history WHERE date < ? AND product_id IN (
        SELECT p.id FROM products p JOIN users u ON u.id = p.user_id WHERE u.plan = ?
      )
    `).bind(cutoff, plan).run();
  }
}

// ---------- Router ----------
async function router(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  if (method === "OPTIONS") return new Response(null, { headers: CORS_HEADERS });

  // --- Auth ---
  if (method === "POST" && path === "/auth/register") {
    const body = await request.json().catch(() => ({}));
    const { email, password } = body;
    if (!email || !password || password.length < 6) {
      return json({ error: "Email e password (min. 6 caratteri) richiesti." }, 400);
    }
    const existing = await env.DB.prepare("SELECT id FROM users WHERE email=?").bind(email).first();
    if (existing) return json({ error: "Email già registrata." }, 409);

    const { hash, salt } = await hashPassword(password);
    const id = crypto.randomUUID();
    await env.DB.prepare("INSERT INTO users (id,email,password_hash,salt,plan,created_at) VALUES (?,?,?,?,?,?)")
      .bind(id, email, hash, salt, "free", Date.now()).run();
    const token = await signToken({ sub: id, exp: Date.now() + 90 * 24 * 60 * 60 * 1000 }, env.JWT_SECRET);
    return json({ token, plan: "free" }, 201);
  }

  if (method === "POST" && path === "/auth/login") {
    const body = await request.json().catch(() => ({}));
    const { email, password } = body;
    const user = await env.DB.prepare("SELECT * FROM users WHERE email=?").bind(email).first();
    if (!user || !(await verifyPassword(password, user.password_hash, user.salt))) {
      return json({ error: "Email o password errati." }, 401);
    }
    const token = await signToken({ sub: user.id, exp: Date.now() + 90 * 24 * 60 * 60 * 1000 }, env.JWT_SECRET);
    return json({ token, plan: user.plan });
  }

  // --- Da qui in poi serve autenticazione ---
  const user = await requireAuth(request, env);
  if (!user) return json({ error: "Non autenticato." }, 401);

  if (method === "GET" && path === "/me") {
    return json({ email: user.email, plan: user.plan });
  }

  if (method === "GET" && path === "/products") {
    const { results } = await env.DB.prepare(
      "SELECT * FROM products WHERE user_id=? ORDER BY created_at DESC"
    ).bind(user.id).all();
    return json(results.map(formatProduct));
  }

  if (method === "POST" && path === "/products") {
    const body = await request.json().catch(() => ({}));
    const { url: productUrl, title, currentPrice, targetPrice } = body;
    if (!productUrl || !title || typeof currentPrice !== "number") {
      return json({ error: "url, title e currentPrice sono richiesti." }, 400);
    }
    const { count } = await env.DB.prepare("SELECT COUNT(*) as count FROM products WHERE user_id=?").bind(user.id).first();
    const limit = PLAN_LIMITS[user.plan]?.maxProducts ?? PLAN_LIMITS.free.maxProducts;
    if (count >= limit) {
      return json({ error: `Limite di ${limit} prodotti raggiunto per il piano ${user.plan}.` }, 403);
    }

    const id = crypto.randomUUID();
    const now = Date.now();
    await env.DB.prepare("INSERT INTO products (id,user_id,url,title,current_price,target_price,created_at) VALUES (?,?,?,?,?,?,?)")
      .bind(id, user.id, productUrl, title, currentPrice, targetPrice ?? null, now).run();
    await env.DB.prepare("INSERT INTO price_history (id, product_id, price, date) VALUES (?,?,?,?)")
      .bind(crypto.randomUUID(), id, currentPrice, now).run();

    const product = await env.DB.prepare("SELECT * FROM products WHERE id=?").bind(id).first();
    return json(formatProduct(product), 201);
  }

  const productIdMatch = path.match(/^\/products\/([^/]+)$/);
  if (productIdMatch) {
    const productId = productIdMatch[1];
    const owned = await env.DB.prepare("SELECT * FROM products WHERE id=? AND user_id=?").bind(productId, user.id).first();
    if (!owned) return json({ error: "Prodotto non trovato." }, 404);

    if (method === "PATCH") {
      const body = await request.json().catch(() => ({}));
      await env.DB.prepare("UPDATE products SET target_price=? WHERE id=?")
        .bind(body.targetPrice ?? null, productId).run();
      const updated = await env.DB.prepare("SELECT * FROM products WHERE id=?").bind(productId).first();
      return json(formatProduct(updated));
    }
    if (method === "DELETE") {
      await env.DB.prepare("DELETE FROM products WHERE id=?").bind(productId).run();
      return json({ deleted: true });
    }
  }

  const historyMatch = path.match(/^\/products\/([^/]+)\/history$/);
  if (historyMatch && method === "GET") {
    const productId = historyMatch[1];
    const owned = await env.DB.prepare("SELECT id FROM products WHERE id=? AND user_id=?").bind(productId, user.id).first();
    if (!owned) return json({ error: "Prodotto non trovato." }, 404);
    const { results } = await env.DB.prepare(
      "SELECT price, date FROM price_history WHERE product_id=? ORDER BY date ASC"
    ).bind(productId).all();
    return json(results);
  }

  if (method === "POST" && path === "/check-now") {
    const { results } = await env.DB.prepare("SELECT * FROM products WHERE user_id=? LIMIT 100").bind(user.id).all();
    const outcomes = [];
    for (const product of results) {
      outcomes.push({ id: product.id, ...(await checkOneProduct(env, product)) });
    }
    return json({ checked: outcomes.length, outcomes });
  }

  return json({ error: "Non trovato." }, 404);
}

function formatProduct(row) {
  return {
    id: row.id,
    url: row.url,
    title: row.title,
    currentPrice: row.current_price,
    targetPrice: row.target_price,
    lastCheckedAt: row.last_checked_at,
    lastCheckError: row.last_check_error,
    createdAt: row.created_at,
  };
}

export default {
  async fetch(request, env) {
    try {
      return await router(request, env);
    } catch (err) {
      return json({ error: "Errore interno.", detail: String(err && err.message || err) }, 500);
    }
  },
  async scheduled(event, env, ctx) {
    ctx.waitUntil(checkDueProducts(env));
  },
};
